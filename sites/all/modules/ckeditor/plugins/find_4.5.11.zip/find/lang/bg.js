/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'bg', {
	find: 'Търсене',
	findOptions: 'Find Options',
	findWhat: 'Търси за:',
	matchCase: 'Съвпадение',
	matchCyclic: 'Циклично съвпадение',
	matchWord: 'Съвпадение с дума',
	notFoundMsg: 'Указаният текст не е намерен.',
	replace: 'Препокриване',
	replaceAll: 'Препокрий всички',
	replaceSuccessMsg: '%1 occurrence(s) replaced.',
	replaceWith: 'Препокрива с:',
	title: 'Търсене и препокриване'
} );
