/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'ku', {
	find: 'گەڕان',
	findOptions: 'هەڵبژاردەکانی گەڕان',
	findWhat: 'گەڕان بەدووای:',
	matchCase: 'جیاکردنەوه لەنێوان پیتی گەورەو بچووك',
	matchCyclic: 'گەڕان لەهەموو پەڕەکه',
	matchWord: 'تەنەا هەموو وشەکه',
	notFoundMsg: 'هیچ دەقه گەڕانێك نەدۆزراوه.',
	replace: 'لەبریدانان',
	replaceAll: 'لەبریدانانی هەمووی',
	replaceSuccessMsg: ' پێشهاتە(ی) لەبری دانرا. %1',
	replaceWith: 'لەبریدانان به:',
	title: 'گەڕان و لەبریدانان'
} );
