/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'bn', {
	find: 'খুজিঁ',
	findOptions: 'Find Options',
	findWhat: 'যা খুঁজতে হবে:',
	matchCase: 'কেস মিলাও',
	matchCyclic: 'Match cyclic',
	matchWord: 'পুরা শব্দ মেলাও',
	notFoundMsg: 'আপনার উল্লেখিত টেকস্ট পাওয়া যায়নি',
	replace: 'রিপ্লেস',
	replaceAll: 'সব বদলে দাও',
	replaceSuccessMsg: '%1 occurrence(s) replaced.',
	replaceWith: 'যার সাথে বদলাতে হবে:',
	title: 'Find and Replace'
} );
