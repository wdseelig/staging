/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'lv', {
	find: 'Meklēt',
	findOptions: 'Meklēt uzstādījumi',
	findWhat: 'Meklēt:',
	matchCase: 'Reģistrjūtīgs',
	matchCyclic: 'Sakrist cikliski',
	matchWord: 'Jāsakrīt pilnībā',
	notFoundMsg: 'Norādītā frāze netika atrasta.',
	replace: 'Nomainīt',
	replaceAll: 'Aizvietot visu',
	replaceSuccessMsg: '%1 gadījums(i) aizvietoti',
	replaceWith: 'Nomainīt uz:',
	title: 'Meklēt un aizvietot'
} );
