/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'sq', {
	find: 'Gjej',
	findOptions: 'Gjejë Alternativat',
	findWhat: 'Gjej çka:',
	matchCase: 'Rasti i përputhjes',
	matchCyclic: 'Përputh ciklikun',
	matchWord: 'Përputh fjalën e tërë',
	notFoundMsg: 'Teksti i caktuar nuk mundej të gjendet.',
	replace: 'Zëvendëso',
	replaceAll: 'Zëvendëso të gjitha',
	replaceSuccessMsg: '%1 rast(e) u zëvendësua(n).',
	replaceWith: 'Zëvendëso me:',
	title: 'Gjej dhe Zëvendëso'
} );
