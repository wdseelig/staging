/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'mn', {
	find: 'Хайх',
	findOptions: 'Хайх сонголтууд',
	findWhat: 'Хайх үг/үсэг:',
	matchCase: 'Тэнцэх төлөв',
	matchCyclic: 'Match cyclic',
	matchWord: 'Тэнцэх бүтэн үг',
	notFoundMsg: 'Хайсан бичвэрийг олсонгүй.',
	replace: 'Орлуулах',
	replaceAll: 'Бүгдийг нь солих',
	replaceSuccessMsg: '%1 occurrence(s) replaced.',
	replaceWith: 'Солих үг:',
	title: 'Хайж орлуулах'
} );
