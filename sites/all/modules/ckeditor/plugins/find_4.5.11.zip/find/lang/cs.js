/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'cs', {
	find: 'Hledat',
	findOptions: 'Možnosti hledání',
	findWhat: 'Co hledat:',
	matchCase: 'Rozlišovat velikost písma',
	matchCyclic: 'Procházet opakovaně',
	matchWord: 'Pouze celá slova',
	notFoundMsg: 'Hledaný text nebyl nalezen.',
	replace: 'Nahradit',
	replaceAll: 'Nahradit vše',
	replaceSuccessMsg: '%1 nahrazení.',
	replaceWith: 'Čím nahradit:',
	title: 'Najít a nahradit'
} );
