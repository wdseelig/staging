/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'nl', {
	find: 'Zoeken',
	findOptions: 'Zoekopties',
	findWhat: 'Zoeken naar:',
	matchCase: 'Hoofdlettergevoelig',
	matchCyclic: 'Doorlopend zoeken',
	matchWord: 'Hele woord moet voorkomen',
	notFoundMsg: 'De opgegeven tekst is niet gevonden.',
	replace: 'Vervangen',
	replaceAll: 'Alles vervangen',
	replaceSuccessMsg: '%1 resultaten vervangen.',
	replaceWith: 'Vervangen met:',
	title: 'Zoeken en vervangen'
} );
