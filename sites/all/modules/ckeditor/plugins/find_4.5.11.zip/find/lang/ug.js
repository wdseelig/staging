/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'find', 'ug', {
	find: 'ئىزدە',
	findOptions: 'ئىزدەش تاللانمىسى',
	findWhat: 'ئىزدە:',
	matchCase: 'چوڭ كىچىك ھەرپنى پەرقلەندۈر',
	matchCyclic: 'ئايلانما ماسلىشىش',
	matchWord: 'پۈتۈن سۆز ماسلىشىش',
	notFoundMsg: 'بەلگىلەنگەن تېكىستنى تاپالمىدى',
	replace: 'ئالماشتۇر',
	replaceAll: 'ھەممىنى ئالماشتۇر',
	replaceSuccessMsg: 'جەمئى %1 جايدىكى ئالماشتۇرۇش تاماملاندى',
	replaceWith: 'ئالماشتۇر:',
	title: 'ئىزدەپ ئالماشتۇر'
} );
